<?php
    $banner_text = get_sub_field('banner_text');
?>
<section class="banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="banner__inner">
                    <?= $banner_text ?>
                </div>
            </div>
        </div>
    </div>
</section>

