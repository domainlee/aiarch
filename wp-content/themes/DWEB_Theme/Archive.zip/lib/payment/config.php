<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$vnp_TmnCode = "CALISTA1"; //Mã website tại VNPAY
$vnp_HashSecret = "WMCOLKEDKBUZYFOLFFDDCKEGBRXGEISN"; //Chuỗi bí mật
$vnp_Url = "http://sandbox.vnpayment.vn/paymentv2/vpcpay.html";
$vnp_Returnurl = "http://theme.com/vnpay_php/vnpay_return.php";