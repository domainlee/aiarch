<?php get_header(); ?>
<?php
    get_template_part('loop_list');
?>
<?php get_footer(); ?>
